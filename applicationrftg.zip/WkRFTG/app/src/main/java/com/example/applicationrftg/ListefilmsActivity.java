package com.example.applicationrftg;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class ListefilmsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listefilms);

}
    public void ouvrirPage(View view) {
        Intent intent = new Intent(this, PanierActivity.class);
        startActivity(intent);

    }
}
